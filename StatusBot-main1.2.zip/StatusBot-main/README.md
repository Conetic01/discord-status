Thank you for purchasing my code. I would appreciate your feedback!

# statusBot

What is it? A bot that assigns you a role for the corresponding status,
perfect for community/giveaway servers.

# credits & license

Bot was created by Kangaroo#6969, selling bot on your own is prohibited.

# setup step-by-step

1. Fill out the config.json file
2. Open a terminal (In VSCode: Ctrl + `)
3. Run: npm install
4. Make sure to enable Privileged Gateway Intents (on developer portal) for presence and members
5. Run: node .

# contact & support

discord: Kangaroo#6969
discord: [discord.gg/lights](https://discord.gg/GtSEhcqb9J)
